package spring1;

public interface Empleados {

	public String getTareas();
	public String getInforme();
	
}
