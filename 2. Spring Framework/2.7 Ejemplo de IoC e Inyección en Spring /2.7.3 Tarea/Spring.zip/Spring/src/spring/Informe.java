package spring;

public class Informe implements CreacionInformes {

	@Override
	public String getInforme() {
		// TODO Auto-generated method stub
		return "[Esta es la presentacion del informe]";
	}

}
