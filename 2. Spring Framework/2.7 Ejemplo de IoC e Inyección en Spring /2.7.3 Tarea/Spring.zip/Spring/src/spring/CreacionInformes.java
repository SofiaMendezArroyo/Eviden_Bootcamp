package spring;

public interface CreacionInformes {

	public String getInforme();
}
