package es.springcore;

public interface ServicioNotificacion {
	
	void enviarNotificación(String mensaje);
}

