package ioc;

public interface ServicioNotificacion {
	
	void enviarNotificación(String mensaje);
}


