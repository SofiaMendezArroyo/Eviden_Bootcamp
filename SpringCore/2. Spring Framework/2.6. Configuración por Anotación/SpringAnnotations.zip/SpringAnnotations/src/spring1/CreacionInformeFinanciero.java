package spring1;

public interface CreacionInformeFinanciero {

	public String getInformeFinanciero();
}
