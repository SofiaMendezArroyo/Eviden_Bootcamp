
public class MainHello {

	public static void main(String[] args) {

		System.out.println("HOLA");
		for(int i=0; i <3; i++) {
			int z = i;
		}
		System.out.println("ADIOS");
	}

}
