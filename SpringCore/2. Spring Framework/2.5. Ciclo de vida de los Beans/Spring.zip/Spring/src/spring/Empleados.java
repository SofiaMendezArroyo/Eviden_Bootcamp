package spring;

public interface Empleados {

	public String getTareas();
	
	public String getInforme();
	
	
}
